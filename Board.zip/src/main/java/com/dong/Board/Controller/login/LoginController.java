/*
 * package com.dong.Board.Controller.login;
 * 
 * import org.springframework.beans.factory.annotation.Autowired; import
 * org.springframework.stereotype.Controller; import
 * org.springframework.web.bind.annotation.GetMapping; import
 * org.springframework.web.bind.annotation.PostMapping; import
 * org.springframework.web.bind.annotation.RequestMapping; import
 * org.springframework.web.bind.annotation.RequestParam;
 * 
 * import com.dong.Board.Service.MemberService; import
 * com.dong.Board.entity.Member;
 * 
 * @RequestMapping("/login")
 * 
 * @Controller public class LoginController {
 * 
 * @Autowired MemberService service;
 * 
 * 
 * @GetMapping("/loginForm") public String loginForm() { return "/login/login";}
 * 
 * 
 * @GetMapping("/accessDenied") public String accessDenied() { return
 * "/login/accessDenied"; } }
 */
