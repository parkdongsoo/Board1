package com.dong.Board.entity;

public enum Role {
	USER_ROLE
}
